package del3;

public class LoggingSomeService implements SomeService {
	/*
	 * Since there are no setter-methods, we use final keyword to ensure
	 * that the fields are not changed after a LoggingSomeService object has 
	 * been constructed. Only one delegate is needed, and only one logger, so no
	 * collection.
	 */
	private final SomeService delegate;
	private final Logger logger;

	/*
	 * Creates a LoggingSomeService object with the given delegate and logger
	 */
	public LoggingSomeService(SomeService delegate, Logger logger) {
		/* 
		 * First check that delegate is not null in constructor. This ensures
		 * that we dont use a method on something that is null. We do the same 
		 * for logger, so that we dont get NullPointerException.
		 */
		if (delegate == null)
			throw new IllegalArgumentException("Cant delegate to null!");
		if (logger == null)
			throw new IllegalArgumentException("Logger cant be null!");
		this.delegate = delegate;
		this.logger = logger;
		
	}

	@Override
	/**
	 * Delegates the job of calculating a magic string to the delegate, and logs the
	 * result before returning it
	 * 
	 * @return A string
	 */
	public String getAMagicString() {
		String magicString = delegate.getAMagicString();
		logger.log(magicString);
		return magicString;
	}

	/**
	 * Delegates the job of calculating a magic number to the delegate, and logs the
	 * result before returning it
	 * 
	 * @return An integer
	 */
	@Override
	public int getAMagicNumber() {
		Integer magicNumber = delegate.getAMagicNumber();
		logger.log(magicNumber.toString());
		return (int) magicNumber;
	}
	
	public static void main(String [] args) {
		Logger logger = new Logger();
		SomeService loggingService = new LoggingSomeService(new SomeServiceImpl(), logger);
		// This should print 42 twice (one for the logger, one for the return) 
		System.out.println(loggingService.getAMagicNumber());
		// This should print [42]
		System.out.println(logger.hasLogged);
		// should print "magic" twice
		System.out.println(loggingService.getAMagicString());
		// Should print [42, magic]
		System.out.println(logger.hasLogged);
		
	}
}
