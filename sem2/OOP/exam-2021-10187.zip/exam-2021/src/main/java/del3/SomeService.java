package del3;

public interface SomeService {

	public String getAMagicString();

	public int getAMagicNumber();
}
