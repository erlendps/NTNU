package testeksamen;

import java.util.ArrayList;
import java.util.List;

public class MeetingRoom {
	private String roomName;
	private int maxNumberOfParticipants;
	private List<String> participants = new ArrayList<>();
	
	/**
	 * Constructor - creates a meeting rom with maximum number of participants
	 * @param maxNumberOfParticipants
	 */
	public MeetingRoom(int maxNumberOfParticipants, String roomName) {
		if (maxNumberOfParticipants < 1)
			throw new IllegalArgumentException("cant be 0 or less");
		if (roomName == null)
			throw new IllegalArgumentException("Name cant be null");
		this.roomName = roomName;
		this.maxNumberOfParticipants = maxNumberOfParticipants;
	}
	
	/**
	 * 
	 * @return the maximum number of participants in this room
	 */
	public int getMaximumNumberOfParticipants() {
		return maxNumberOfParticipants;
	}
	
	/**
	 * 
	 * @return the name of the room
	 */
	public String getRoomName() {
		return roomName;
	}
	
	/**
	 * Adds a participant to the meeting room
	 * @param name the name of the participant
	 * @throws IllegalStateException, if the room is at capacity
	 */
	public void addParticipant(String name) {
		if (participants.contains(name))
			throw new IllegalStateException("Already Added");
		if (name == null)
			throw new IllegalArgumentException("Participant cant be null");
		if (getNumberOfParticipants() == maxNumberOfParticipants)
			throw new IllegalStateException("Max limit reached");
		participants.add(name);
	}
	
	/**
	 * 
	 * @param name the name of a participant
	 * @return whether the participant is present in the meeting room
	 */
	public boolean isPresent(String name) {
		return participants.contains(name);
	}
	
	/**
	 * Removes a participant from the meeting room. If the name is not present, do nothing
	 * @param name the name of a participant
	 */
	public void removeParticipant(String name) {
		if (participants.contains(name))
			participants.remove(name);	
	}
	
	/**
	 * 
	 * @return the current number of participants in the meeting room
	 */
	public int getNumberOfParticipants() {
		return participants.size();
	}
	
	/**
	 * 
	 * @return a list of all current participants in the meeting room
	 */
	public List<String> getParticipants(){
		return new ArrayList<>(participants);
	}
	
}
