# Part 2- Encapsulation and Object Structures

Fill in setters and getters in the [Person](Person.java) class.
You should do this without changing the code in the [Address](Address.java) class.