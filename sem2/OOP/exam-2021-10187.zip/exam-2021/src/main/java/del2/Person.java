package del2;

public class Person {

	// No other fields should be added to this class
	private Address address;

	
	// You do not need to consider the edge case of passing null into the constructor here
	public Person(Address address) {
		this.address = address;
	}
	
	/**
	 * 
	 * @return the street name of this person
	 */
	public String getStreetName() {
		return address.getStreetName();
	}

	/**
	 * Updates the street name of this person
	 * 
	 * @param streetName The street name to update
	 */
	public void setStreetName(String streetName) {
		// since Address class does not have any methods to set its internal fields
		// we need to make a new address object.
		int streetNumber = getStreetNumber();
		this.address = new Address(streetName, streetNumber);
	}
	
	
	public int getStreetNumber() {
		return address.getStreetNumber();
	}

	/**
	 * Updates the street number of this person
	 * 
	 * @param streetNumber A positive integer.
	 * 
	 * @throws IllegalArgumentException If number is not larger than 0.
	 */
	public void setStreetNumber(int streetNumber) {
		if (streetNumber <= 0)
			throw new IllegalArgumentException("StreetNumber must be larger than 0");
		// the same as setStreetName-method. Need to create a new address object
		String streetName = getStreetName();
		this.address = new Address(streetName, streetNumber);
	}

	public static void main(String[] args) {
		Person person = new Person(new Address("Test", 2));
		person.setStreetName("Test2");
		System.out.println(person.getStreetName());
		System.out.println(person.getStreetNumber());
		//person.setStreetNumber(0); throws Exception
		person.setStreetNumber(1);
		System.out.println(person.getStreetName());
		System.out.println(person.getStreetNumber());
	}
}
