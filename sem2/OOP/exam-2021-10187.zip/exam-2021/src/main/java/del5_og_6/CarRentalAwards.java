package del5_og_6;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class CarRentalAwards extends LoyaltyAward {

	private Map<Integer, Integer> carBrandToPoints = Map.of(1, 1, 2, 10, 3, 100, 4, 200, 5, 500);
	// moved the List to inside the setAwardName method. Both because it fixes the bug
	// but also for me, its not natural to have a list of validNames as a field
	// for CarRentalAwards, as it does not have anything to do with it. 
	// It should rather be a field inside the method that validates it.

	public CarRentalAwards(String awardName) {
		super(awardName);
	}

	@Override
	/**
	 * Updates the award name
	 * @param: awardName The name of the award
	 * 
	 * @throws IllegalArgumentException If the award name is not part of the valid
	 *                                  names
	 */
	public void setAwardName(String awardName) {
		List<String> validNames = Arrays.asList("CarRentalAgency1", "CarRentalAgency2");
		if (!validNames.contains(awardName)) {
			throw new IllegalArgumentException("Invalid award name");
		}
		super.setAwardName(awardName);
	}

	/**
	 * Updates the status of the given LoyaltyUser with points based on the map
	 * above. The map means that carBrand 1 will award 1 points, carBrand 2 will
	 * award 10 points etc
	 * 
	 * @param carBrand:    The brand of the car the user has rented. If the brand
	 *                     does not exist 0 points should be awarded
	 * 
	 * @param loyaltyUser: The user that rented the car
	 * 
	 * 
	 */
	public void awardPoints(int carBrand, LoyaltyUser loyaltyUser) {
		Integer points = carBrandToPoints.get(carBrand);
		if (points != null) {
			/*
			 * Here its missing the super keyword. Forgetting the super keyboard
			 * would just call this same method again, so that you get an infinite
			 * loop. 
			 */
			super.awardPoints(points, loyaltyUser);
		}
	}

	public static void main(String[] args) {
		LoyaltyUser user = new LoyaltyUser("Name");
		// What goes wrong here
		// tries to access validNames before its initiated.
		LoyaltyAward award = new CarRentalAwards("CarRentalAgency1"); 
		// What goes wrong here
		// forgetting to call the super method will just send it in an infinite loop.
		award.awardPoints(1, user);
		System.out.println(user.getPoints());
	}

}
