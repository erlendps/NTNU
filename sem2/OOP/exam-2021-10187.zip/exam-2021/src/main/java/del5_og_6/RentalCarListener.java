package del5_og_6;

import java.util.ArrayList;
import java.util.Collection;

/* RentalCar listeners listens to changes in Status for all userNames.*/
public class RentalCarListener implements StatusListener {

	// Collection that keep tracks of which users gets this discount, i.e 
	// being at gold status.
	private Collection<String> userNames = new ArrayList<>();

	@Override
	/**
	 * Method that should be called when a given userName has updated its status.
	 */
	public void statusChanged(String username, String oldStatus, String newStatus) {
		if (newStatus == "Gold") {
			userNames.add(username);
		}
		else if (newStatus != "Gold" && oldStatus == "Gold") {
			userNames.remove(username);
		}
	}

	/**
	 * Get's the discount of a user. Should be a 100 if the user currently has Gold
	 * status, otherwise should be 0.
	 * 
	 * @param username The username of the user
	 * 
	 * @return The discount the user qualifies for.
	 */
	public int getDiscount(String username) {
		if (userNames.contains(username))
			return 100;
		else
			return 0;
	}
}
