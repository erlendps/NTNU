package del4;

import java.util.ArrayList;
import java.util.List;

public class Athlete {
	
	private List<Medal> medals = new ArrayList<Medal>();
	private String country;
	private String name;

	public Athlete(String country, String name, List<Medal> medals) {
		this.name = name;
		this.country = country;
		this.medals = new ArrayList<>(medals);
	}

	public List<Medal> getMedals() {
		return new ArrayList<>(medals);
	}
	
	/**
	 * Helper method that returns the amount of medals an athlete have won of 
	 * a specific type. If Berit has won 3 gold medals, would
	 * countMedalsOf("Gold") return 3
	 * 
	 * @param metal
	 * @return the number of medals won of this metal
	 */
	public int countMedalsOf(String metal) {
		return (int) getMedals().stream()
				.filter(medal -> medal.toString().equals(metal))
				.count();
	}

	public String getCountry() {
		return country;
	}

	public String getName() {
		return name;
	}
	
	/*
	 * Added to better visualize when testing.
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getName());
		sb.append(": ");
		sb.append(medals);
		return sb.toString();
	}
	
	public static void main(String[] args) {
		Athlete a1 = new Athlete("Norway", "Birte", List.of(new Medal("Gold"),
				new Medal("Gold"), new Medal("Silver")));
		// should return 2
		System.out.println(a1.countMedalsOf("Gold"));
		// should return 0
		System.out.println(a1.countMedalsOf("Bronze"));
	}

}