package del1;

public class VaccineTrialVolunteer {
	// fields, need one for id, one to say wether the volunteer got placebo
	// and one field where it says if the volunteer got sick during the testing.
	private String id;
	private final boolean gotPlacebo;
	private boolean gotSick = false;
	
	public VaccineTrialVolunteer(String id, boolean placebo) {
		if (id == null) // volunteer needs an id, in context to class VaccineTrial
			throw new IllegalArgumentException("Volunteer must have an id");
		this.id = id;
		this.gotPlacebo = placebo;
	}

	public String getId() {
		return id;
	}

	/* Whether the volunteer was given a placebo or the actual vaccine */
	public boolean isPlacebo() {
		return gotPlacebo;
	}

	/* Whether the volunteer got sick during the trial period, 
	 * the default value for this should be false */
	public boolean gotSick() {
		return gotSick;
	}

	/*
	 * Updates whether the participant got sick during the trial period
	 */
	public void setGotSick(boolean gotSick) {
		this.gotSick = gotSick;
	}
	
	public static void main(String[] args) {
		VaccineTrialVolunteer vtv = new VaccineTrialVolunteer("12312", false);
		System.out.println(vtv.getId());
		System.out.println(vtv.isPlacebo());
		System.out.println(vtv.gotSick());
		vtv.setGotSick(true);
		System.out.println(vtv.gotSick());
	}

}
